<?php
/* 2014-09-14 20:01:39 */
$title = 'Sommaire > Statistiques';
$close = 'Fermer';
$nfw_help = <<<'EOT'

<h3><strong>Statistiques Mensuelles</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Les statistiques sont tirées du journal du pare-feu qui est, par défaut, réinitialisé le 1er jour de chaque mois.
Vous pouvez consuler ce journal en cliquant sur le menu "Pare-Feu > Journal".</p>

<hr class="dotted" size="1">

<h3><strong>Performances</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Indique le temps qu'il a fallu à NinjaFirewall pour intercepter, analyser et bloquer les requêtes dangereuses.</p>

EOT;

