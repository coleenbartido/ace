<?php
/* 2016-03-28 19:18:45 */
$lang = array (

	'error'				=> 'Erreur',
	'yes'					=> 'Oui',
	'no'					=> 'Non',
	'default'			=> ' (defaut)',
	'pro_only'			=>	'Cette fonctionnalité n\'est disponible que dans la version <font color="#FF0000">Pro+</font> Edition de NinjaFirewall',
	'lic_upgrade'		=>	'mise à niveau',
	'fg'					=>	'File Guard',
	'enable_fg'			=>	'Activer File Guard',
	'detection'			=>	'Détection en temps réel',
	'exclude_title'	=>	'Exclure les fichiers / dossiers suivants (optionnel)',
	'exclude_desc'		=>	'Chaîne de caractères complète ou partielle, sensible à la casse, 255 caractères maximum. Plusieurs valeurs doivent être séparées par des virgules.',
	'eg'					=>	'e.g.,',

	'monitor'			=>	'Surveiller et alerter par e-mail lorsqu\'un visiteur accède à un script PHP ' .
								'qui a été modifié ou créé il y a moins de %s heure(s).',

	'error_cache'		=> 'Impossible d\'écrire dans le répertoire du cache <code>/nfwlog/cache</code>. ' .
								'Assurez-vous que ce répertoire n\'est pas en lecture seule.',

	'js_num'				=>	'Veuillez entrer un chiffre de 1 à 99.',

	'save_conf'			=> 'Sauvegarder les modifications',
	'saved_conf'		=> 'Les modifications ont été enregistrées',
	'error_conf'		=> 'Impossible d\'écrire dans le fichier de configuration <code>/conf/options.php</code>. ' .
								'Assurez-vous que ce fichier n\'est pas en lecture seule.',
);
