<?php
/* 2014-10-15 18:22:59 */
$title = 'Sommaire > Aperçu';
$close = 'Fermer';
$nfw_help = <<<'EOT'

<p>La page Aperçu affiche toutes les informations relatives au bon fonctionnement du pare-feu ainsi que les mises à jour; il vous est conseillé de la consulter fréquemment car, en cas de problèmes, ceux-ci seront indiqués ici.</p>

EOT;

