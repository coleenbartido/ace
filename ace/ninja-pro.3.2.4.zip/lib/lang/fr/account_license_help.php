<?php
/* 2014-09-14 19:53:42 */
$title = 'Compte > Licence';
$close = 'Fermer';
$nfw_help = <<<'EOT'

<h3><strong>Licence Actuelle</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Votre licence est valide jusqu'à la date indiquée. Si, passé cette date, vous ne la renouvelez pas, NinjaFirewall fonctionnera toujours mais vous ne pourrez plus faire de mise à jour du logiciel.
Vous pouvez renouveler votre licence depuis le site <a class="links" style="border-bottom:1px dotted #FFCC25;" href="http://nintechnet.com/ninjafirewall/pro-edition/">NinjaFirewall.com</a> à partir du 30e jour précédent sa date d'expiration.</p>

EOT;

