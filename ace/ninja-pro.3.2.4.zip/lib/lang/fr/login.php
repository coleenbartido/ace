<?php
/* 2014-09-14 19:59:12 */
$lang = array (

	'err_inst'			=> 'Erreur : impossible de trouver le fichier <code>install.php</code>.',
	'install_dir'		=> 'Le répertoire suivant a été trouvé&nbsp;: <code>/install/</code><br />'.
								'Veuillez le supprimer et recharger cette page afin d\'accéder à votre console d\'administration.',

	'session_closed'	=> 'Votre session est terminée.',
	'session_expired'	=> 'Votre session a expiré.',

	'banned'				=>	'Too many failed login attempts, you have been banned for %s minutes.',
	'err_login'			=> 'Utilisateur ou mot de passe invalide.',

	'admin_login'		=> 'Console d\'administration',
	'username'			=>	'Utilisateur :',
	'password'			=>	'Mot de passe :',
	'login'				=>	'Se connecter',
);

