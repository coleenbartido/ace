<?php
/* 2014-09-14 20:01:23 */
$lang = array (
	'error'					=> 'Erreur',
	'firewall'				=> 'Statistiques Mensuelles',

	'no_stats'				=> 'Vous n\'avez pas de statistiques pour le mois en cours.',
	'select_stats'			=> 'Sélectionnez les statistiques à afficher',

	'failed_open'			=> 'Impossible d\'ouvrir le fichier journal',

	'stats_period'			=> 'Période des statistiques',
	'blocked_hack'			=> 'Tentatives de piratage bloquées',
	'severity'				=> 'Sévérité des attaques',
	'critical'				=> 'Critique',
	'high'					=> 'Elevé',
	'medium'					=> 'Moyen',

	'tot_upload'			=> 'Fichiers téléchargés (upload)',
	'ban_ip'					=> 'IP bannies',

	'benchmarks'			=> 'Performances',
	'aver_time'				=> 'Durée moyenne par requête',
	'fast_req'				=>	'Requête la plus rapide',
	'slow_req'				=> 'Requête la plus lente',
);

