<?php
/* 2014-09-14 19:54:24 */
$title = 'Compte > Mises à jour';
$close = 'Fermer';
$nfw_help = <<<'EOT'

<h3><strong>Mises à jour disponibles</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Lorsqu'elles sont disponibles, les mises à jour de NinjaFirewall se font depuis cette page, simplement en cliquant sur le bouton vous invitant à le faire.</p>

<p><img src="static/bullet_off.gif">&nbsp;Vous pouvez aussi suivre notre compte Twitter (@nintechnet) où seront indiquées les mises à jour.</p>

EOT;

