<?php
/* 2014-09-14 19:08:00 */
$title = 'Account > Updates';
$close = 'Close';
$nfw_help = <<<'EOT'

<h3><strong>Available updates</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;After installing NinjaFirewall, all available updates &amp; upgrades could be simply installed from this page. This applies to files and security rules as well.</p>

<p><img src="static/bullet_off.gif">&nbsp;You can also follow us on Twitter (@nintechnet) to get immediate notifications about updates.</p>
EOT;

