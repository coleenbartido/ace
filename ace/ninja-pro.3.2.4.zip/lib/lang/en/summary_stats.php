<?php
/* 2014-09-14 19:52:56 */
$lang = array (
	'error'					=> 'Error',
	'firewall'				=> 'Monthly stats',

	'no_stats'				=> 'You do not have any statistics for the current month.',
	'select_stats'			=> 'Select monthly stats to view',

	'failed_open'			=> 'Unable to open logfile',

	'stats_period'			=> 'Statistics period',
	'blocked_hack'			=> 'Blocked hacking attempts',
	'severity'				=> 'Hacking attempts severity',
	'critical'				=> 'Critical',
	'high'					=> 'High',
	'medium'					=> 'Medium',

	'tot_upload'			=> 'Uploaded files',
	'ban_ip'					=> 'Banned IPs',

	'benchmarks'			=> 'Benchmarks',
	'aver_time'				=> 'Average time per request',
	'fast_req'				=>	'Fastest request',
	'slow_req'				=> 'Slowest request',
);

