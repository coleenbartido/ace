<?php
/* 2014-09-14 19:51:30 */
$lang = array (

	'err_inst'			=> 'Error : cannot find the <code>install.php</code> file.',
	'install_dir'		=> 'The following directory was found: <code>/install/</code><br />' .
								'Please delete it and reload this page to access the login page.',

	'session_closed'	=> 'Your session has been closed.',
	'session_expired'	=> 'Your session has expired.',

	'banned'				=>	'Too many failed login attempts, you have been banned for %s minutes.',
	'err_login'			=> 'Wrong username or password.',
	'admin_login'		=> 'Admin login',
	'username'			=>	'Username:',
	'password'			=>	'Password:',
	'login'				=>	'Login',
);

