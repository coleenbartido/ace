<?php
/* 2014-10-15 18:23:27 */
$title = 'Summary > Overview';
$close = 'Close';
$nfw_help = <<<'EOT'

<p>This is the Overview page; it shows information about the firewall status. We recommend you keep an eye on it because, in case of problems, all possible errors and warnings will be displayed here.</p>

EOT;

