<?php
/* 2014-09-14 19:53:16 */
$title = 'Summary > Statistics';
$close = 'Close';
$nfw_help = <<<'EOT'

<h3><strong>Monthly stats</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Statistics are taken from the current log which is, by default, rotated on the first day of each month.
You can view the log by clicking on the "Firewall Log" menu.</p>


<hr class="dotted" size="1">


<h3><strong>Benchmarks</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Benchmarks show the time NinjaFirewall took, in seconds, to proceed each request it has blocked.</p>

EOT;

