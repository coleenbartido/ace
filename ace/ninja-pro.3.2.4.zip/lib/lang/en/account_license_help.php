<?php
/* 2014-09-14 19:07:10 */
$title = 'Account > License';
$close = 'Close';
$nfw_help = <<<'EOT'

<h3><strong>License</strong></h3>
<p><img src="static/bullet_off.gif">&nbsp;Your license is valid until the indicated expiration date. If you don't renew it after this date, NinjaFirewall will keep working and protecting your website as usual, but updates/upgrades will stop.
You can renew your license from <a class="links" style="border-bottom:1px dotted #FFCC25;" href="http://nintechnet.com/ninjafirewall/pro-edition/">NinjaFirewall.com</a> website 30 days before its expiration date.</p>

EOT;

